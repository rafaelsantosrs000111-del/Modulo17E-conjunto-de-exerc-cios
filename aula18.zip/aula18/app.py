from flask import Flask, render_template, session, redirect, url_for, request

app = Flask(__name__)

# 🔐 Chave secreta (obrigatória para sessões)
app.secret_key = "chave_super_secreta_123"

@app.route("/")
def home():
    return render_template("base.html")

# ------------------------
# ROTA LOGIN
# ------------------------
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")

        if not username:
            return render_template("login.html", erro="Insere um nome!")

        # Guardar na sessão
        session["user"] = username

        return redirect(url_for("perfil"))

    return render_template("login.html")

# ------------------------
# ROTA PERFIL
# ------------------------
@app.route("/perfil")
def perfil():
    if "user" in session:
        return render_template("perfil.html", nome=session["user"])

    return redirect(url_for("login"))

# ------------------------
# ROTA LOGOUT
# ------------------------
@app.route("/logout")
def logout():
    session.pop("user", None)
    return redirect(url_for("home"))

if __name__ == "__main__":
    app.run(debug=True)