from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("contacto.html")

@app.route("/contactos", methods=["POST"])
def contacto():

    nome = request.form["nome"]
    email = request.form["email"]
    mensagem = request.form["mensagem"]

    
    if not nome or not email or not mensagem:
        return "Erro: Todos os campos são obrigatórios!", 400

    return render_template("resultado_contacto.html",
                           nome=nome,
                           email=email,
                           mensagem=mensagem)

if __name__ == "__main__":
    app.run(debug=True)

