@app.route("/relatorio/recurso/<int:id>")
@login_required
def relatorio_recurso(id):

    db = get_db()

    rows = db.execute("""
        SELECT reservas.*, recursos.nome AS recurso_nome, users.username
        FROM reservas
        JOIN recursos ON reservas.recurso_id = recursos.id
        JOIN users ON reservas.user_id = users.id
        WHERE recurso_id = ?
        ORDER BY data, hora
    """, (id,)).fetchall()

    return render_template("relatorio_recurso.html", reservas=rows)

@app.route("/relatorio/data")
@login_required
def relatorio_data():

    data = request.args.get("data")

    db = get_db()

    rows = db.execute("""
        SELECT reservas.*, recursos.nome AS recurso_nome
        FROM reservas
        JOIN recursos ON reservas.recurso_id = recursos.id
        WHERE data = ?
        ORDER BY hora
    """, (data,)).fetchall()

    return render_template(
        "relatorio_data.html",
        reservas=rows,
        data=data
    )

@app.route("/relatorio/minhas")
@login_required
def minhas_reservas():

    db = get_db()

    rows = db.execute("""
        SELECT reservas.*, recursos.nome AS recurso_nome
        FROM reservas
        JOIN recursos ON reservas.recurso_id = recursos.id
        WHERE user_id = ?
        ORDER BY data, hora
    """, (session["user_id"],)).fetchall()

    return render_template("relatorio_minhas.html", reservas=rows)