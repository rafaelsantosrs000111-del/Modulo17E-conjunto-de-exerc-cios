from flask import Flask

app = Flask(__name__)


@app.route("/")
def home():
    return "<h1>Bem-vindo!</h1><p>Esta é a página inicial da minha aplicação Flask.</p>"


@app.route("/sobre")
def sobre():
    return "<h1>Sobre</h1><p>Esta aplicação foi criada para aprender Flask.</p>"


@app.route("/contactos")
def contactos():
    return "<h1>Contactos</h1><p>Email: rafaelsantosrs000111@email.com</p>"

if __name__ == "__main__":
    app.run(debug=True)