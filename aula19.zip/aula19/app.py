from flask import Flask, render_template, request, redirect, session

app = Flask(__name__)
app.secret_key = "chave_super_secreta"

@app.route("/")
def home():
    return render_template("base.html")

# Mostrar formulário
@app.route("/login", methods=["GET"])
def login_form():
    return render_template("login.html")

# Processar login
@app.route("/login", methods=["POST"])
def login():
    username = request.form["username"]
    password = request.form["password"]

    if username == "admin" and password == "123":
        session["user"] = username
        return redirect("/")
    
    return render_template("login.html", erro="Credenciais inválidas")

# Logout
@app.route("/logout")
def logout():
    session.pop("user", None)
    return redirect("/")

# Página protegida
@app.route("/perfil")
def perfil():
    if "user" not in session:
        return redirect("/login")
    return "Página privada do utilizador"

if __name__ == "__main__":
    app.run(debug=True)