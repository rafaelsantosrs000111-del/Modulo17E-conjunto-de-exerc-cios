from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def formulario():
    if request.method == "POST":
        
        # 1️⃣ Obter dados do formulário
        nome = request.form.get("nome", "").strip()
        email = request.form.get("email", "").strip().lower()
        idade = request.form.get("idade", "").strip()
        mensagem = request.form.get("mensagem", "").strip()

        # 2️⃣ Validação de campos vazios
        if not nome or not email or not idade or not mensagem:
            return render_template("form.html", erro="Todos os campos são obrigatórios!")

        # 3️⃣ Validação de email simples
        if "@" not in email or "." not in email:
            return render_template("form.html", erro="Email inválido!")

        # 4️⃣ Validação de idade mínima
        try:
            idade = int(idade)
            if idade < 18:
                return render_template("form.html", erro="Deves ter pelo menos 18 anos.")
        except ValueError:
            return render_template("form.html", erro="Idade inválida.")

        # Se tudo estiver correto
        return render_template("form.html", sucesso="Formulário enviado com sucesso!")

    return render_template("form.html")


if __name__ == "__main__":
    app.run(debug=True)