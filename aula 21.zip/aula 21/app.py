from flask import Flask, render_template, request, redirect, session
from functools import wraps

app = Flask(__name__)
app.secret_key = "segredo"

def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "user" not in session:
            return redirect("/login")
        return f(*args, **kwargs)
    return wrapper

@app.route("/")
def home():
    return "Página inicial"

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]

        session["user"] = username
        return redirect("/dashboard")

    return """
    <form method="POST">
        <input name="username" placeholder="Username">
        <button type="submit">Login</button>
    </form>
    """

@app.route("/logout")
def logout():
    session.pop("user", None)
    return redirect("/")

@app.route("/dashboard")
@login_required
def dashboard():
    return "Dashboard privado"

@app.route("/perfil")
@login_required
def perfil():
    return "Página de perfil do utilizador"

@app.route("/reservas")
@login_required
def reservas():
    return "Lista de reservas"