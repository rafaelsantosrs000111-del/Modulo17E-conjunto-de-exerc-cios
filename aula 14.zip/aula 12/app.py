from flask import Flask, request

app = Flask(__name__)


@app.route("/hello/<nome>")
def hello(nome):
    return f"<h1>Olá, {nome}! Bem-vindo ao Flask!</h1>"


@app.route("/form", methods=["GET", "POST"])
def form():
    if request.method == "POST":
        nome = request.form["nome"]
        email = request.form["email"]
        return f"<h2>Dados recebidos:</h2><p>Nome: {nome}</p><p>Email: {email}</p>"

    return """
    <h1>Formulário</h1>
    <form method="POST">
        Nome: <input type="text" name="nome"><br><br>
        Email: <input type="email" name="email"><br><br>
        <button type="submit">Enviar</button>
    </form>
    """

if __name__ == "__main__":
    app.run(debug=True)