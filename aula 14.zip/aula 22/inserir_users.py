import sqlite3

conn = sqlite3.connect("database.db")
cursor = conn.cursor()

cursor.execute("""
    INSERT INTO users (username, email, password)
    VALUES (?, ?, ?)
""", ("ana", "ana@email.com", "123"))

cursor.execute("""
    INSERT INTO users (username, email, password)
    VALUES (?, ?, ?)
""", ("joao", "joao@email.com", "456"))

conn.commit()
conn.close()

print("Utilizadores inseridos com sucesso!")