import sqlite3

conn = sqlite3.connect("database.db")
conn.close()

print("Base de dados criada com sucesso!")