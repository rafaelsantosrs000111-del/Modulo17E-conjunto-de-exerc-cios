from flask import Flask, render_template

app = Flask(__name__)

@app.route("/perfil/<nome>")
def perfil(nome):
    idade = 20
    hobbies = ["Programar", "Jogos", "Música", "Desporto"]

    return render_template(
        "perfil.html",
        nome=nome,
        idade=idade,
        hobbies=hobbies
    )

if __name__ == "__main__":
    app.run(debug=True)