from flask import Flask, render_template, request, redirect, session, g
import sqlite3
from functools import wraps

app = Flask(__name__)
app.secret_key = "segredo"


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect("database.db")
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(e=None):
    db = g.pop("db", None)
    if db:
        db.close()


def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "user_id" not in session:
            return redirect("/login")
        return f(*args, **kwargs)
    return decorated_function


@app.route("/reservas")
@login_required
def reservas():
    db = get_db()
    rows = db.execute("""
        SELECT * FROM reservas
        WHERE user_id = ?
        ORDER BY data, hora
    """, (session["user_id"],)).fetchall()

    return render_template("reservas.html", reservas=rows)


@app.route("/criar-reserva")
@login_required
def form_criar_reserva():
    return render_template("criar_reserva.html")


@app.route("/criar-reserva", methods=["POST"])
@login_required
def criar_reserva():
    recurso = request.form["recurso"]
    data = request.form["data"]
    hora = request.form["hora"]
    obs = request.form["observacoes"]

    db = get_db()
    db.execute("""
        INSERT INTO reservas (user_id, recurso, data, hora, observacoes)
        VALUES (?, ?, ?, ?, ?)
    """, (session["user_id"], recurso, data, hora, obs))
    db.commit()

    return redirect("/reservas")


@app.route("/editar-reserva/<int:id>")
@login_required
def editar_reserva(id):
    db = get_db()
    reserva = db.execute("""
        SELECT * FROM reservas
        WHERE id = ? AND user_id = ?
    """, (id, session["user_id"])).fetchone()

    if reserva is None:
        return redirect("/reservas")

    return render_template("editar_reserva.html", r=reserva)


@app.route("/editar-reserva/<int:id>", methods=["POST"])
@login_required
def atualizar_reserva(id):
    recurso = request.form["recurso"]
    data = request.form["data"]
    hora = request.form["hora"]
    obs = request.form["observacoes"]

    db = get_db()
    db.execute("""
        UPDATE reservas
        SET recurso = ?, data = ?, hora = ?, observacoes = ?
        WHERE id = ? AND user_id = ?
    """, (recurso, data, hora, obs, id, session["user_id"]))
    db.commit()

    return redirect("/reservas")


@app.route("/apagar-reserva/<int:id>")
@login_required
def apagar_reserva(id):
    db = get_db()
    db.execute("""
        DELETE FROM reservas
        WHERE id = ? AND user_id = ?
    """, (id, session["user_id"]))
    db.commit()

    return redirect("/reservas")

if __name__ == "__main__":
    app.run(debug=True)