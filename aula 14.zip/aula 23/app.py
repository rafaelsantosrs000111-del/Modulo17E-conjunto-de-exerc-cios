from flask import Flask, render_template, request, redirect, g
import sqlite3

app = Flask(__name__)


def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect("database.db")
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(e=None):
    db = g.pop('db', None)
    if db is not None:
        db.close()

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"]
        email = request.form["email"]
        password = request.form["password"]

        db = get_db()
        db.execute("""
            INSERT INTO users (username, email, password)
            VALUES (?, ?, ?)
        """, (username, email, password))
        db.commit()

        return redirect("/users")

    return render_template("register.html")


@app.route("/users")
def users():
    db = get_db()
    rows = db.execute("SELECT * FROM users").fetchall()
    return render_template("users.html", users=rows)

@app.route("/edit/<int:id>")
def edit(id):
    db = get_db()
    user = db.execute("SELECT * FROM users WHERE id = ?", (id,)).fetchone()
    return render_template("edit.html", user=user)


@app.route("/edit/<int:id>", methods=["POST"])
def update(id):
    username = request.form["username"]
    email = request.form["email"]

    db = get_db()
    db.execute("""
        UPDATE users
        SET username = ?, email = ?
        WHERE id = ?
    """, (username, email, id))
    db.commit()

    return redirect("/users")


@app.route("/delete/<int:id>")
def delete(id):
    db = get_db()
    db.execute("DELETE FROM users WHERE id = ?", (id,))
    db.commit()

    return redirect("/users")

if __name__ == "__main__":
    app.run(debug=True)