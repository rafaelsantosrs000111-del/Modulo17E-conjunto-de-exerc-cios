@app.route("/criar-reserva")
@login_required
def criar_reserva_form():
    db = get_db()
    recursos = db.execute("SELECT * FROM recursos").fetchall()
    return render_template("criar_reserva.html", recursos=recursos)

@app.route("/criar-reserva", methods=["POST"])
@login_required
def criar_reserva():

    recurso_id = request.form["recurso_id"]
    data = request.form["data"]
    hora = request.form["hora"]
    obs = request.form["observacoes"]

    db = get_db()

    db.execute("""
        INSERT INTO reservas (user_id, recurso_id, data, hora, observacoes)
        VALUES (?, ?, ?, ?, ?)
    """, (session["user_id"], recurso_id, data, hora, obs))

    db.commit()

    return redirect("/reservas")

@app.route("/reservas")
@login_required
def reservas():

    db = get_db()

    rows = db.execute("""
        SELECT reservas.*, recursos.nome AS recurso_nome
        FROM reservas
        JOIN recursos ON reservas.recurso_id = recursos.id
        WHERE reservas.user_id = ?
        ORDER BY data, hora
    """, (session["user_id"],)).fetchall()

    return render_template("reservas.html", reservas=rows)