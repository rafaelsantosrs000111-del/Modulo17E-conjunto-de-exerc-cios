import sqlite3

conn = sqlite3.connect("database.db")
db = conn.cursor()

db.execute("""
CREATE TABLE IF NOT EXISTS recursos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT UNIQUE,
    descricao TEXT
)
""")

db.execute("""
CREATE TABLE IF NOT EXISTS reservas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    recurso_id INTEGER,
    data TEXT,
    hora TEXT,
    observacoes TEXT,
    FOREIGN KEY (recurso_id) REFERENCES recursos(id)
)
""")

conn.commit()
conn.close()

conn = sqlite3.connect("database.db")
db = conn.cursor()

db.execute(
    "INSERT INTO recursos (nome, descricao) VALUES (?, ?)",
    ("Sala 1", "Sala de reuniões")
)

conn.commit()
conn.close()

recursos = [
    ("Sala 2", "Sala pequena"),
    ("Projetor", "Projetor HD"),
    ("Laboratório", "Lab informática")
]

db.executemany(
    "INSERT INTO recursos (nome, descricao) VALUES (?, ?)",
    recursos
)

conn = sqlite3.connect("database.db")
db = conn.cursor()

rows = db.execute("SELECT * FROM recursos").fetchall()

for r in rows:
    print(r)

conn.close()

conn = sqlite3.connect("database.db")
db = conn.cursor()

db.execute(
    "UPDATE recursos SET descricao = ? WHERE id = ?",
    ("Sala principal de reuniões", 1)
)

conn.commit()
conn.close()

conn = sqlite3.connect("database.db")
db = conn.cursor()

db.execute("DELETE FROM recursos WHERE id = ?", (3,))

conn.commit()
conn.close()