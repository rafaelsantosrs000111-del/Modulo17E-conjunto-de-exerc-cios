@app.route("/reservas")
@login_required
def reservas():

    recurso_id = request.args.get("recurso_id")
    data = request.args.get("data")

    query = """
    SELECT reservas.*, recursos.nome AS recurso_nome
    FROM reservas
    JOIN recursos ON reservas.recurso_id = recursos.id
    WHERE reservas.user_id = ?
    """

    params = [session["user_id"]]

    if recurso_id:
        query += " AND recurso_id = ?"
        params.append(recurso_id)

    if data:
        query += " AND data = ?"
        params.append(data)

    query += " ORDER BY data, hora"

    db = get_db()

    rows = db.execute(query, params).fetchall()
    recursos = db.execute("SELECT * FROM recursos").fetchall()

    return render_template(
        "reservas.html",
        reservas=rows,
        recursos=recursos
    )


